Hexlet Brain Games Project
### Hexlet tests and linter status:
[![Actions Status](https://github.com/MaxKtv/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/MaxKtv/python-project-49/actions)

<a href="https://codeclimate.com/github/MaxKtv/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/107a15731a1ffe0766fa/maintainability" /></a>

[![asciicast](https://asciinema.org/a/2sbk6muZk7BQCXt13IyfcWfib.svg)](https://asciinema.org/a/2sbk6muZk7BQCXt13IyfcWfib)

[![asciicast](https://asciinema.org/a/K9SYt8y6JZF3q7SA9I9BLmvX0.svg)](https://asciinema.org/a/K9SYt8y6JZF3q7SA9I9BLmvX0)

[![asciicast](https://asciinema.org/a/e6ilv5tW53uKQSKVnKAePLivI.svg)](https://asciinema.org/a/e6ilv5tW53uKQSKVnKAePLivI)

[![asciicast](https://asciinema.org/a/LMtImohzp5kr2kK6z5YohrtoO.svg)](https://asciinema.org/a/LMtImohzp5kr2kK6z5YohrtoO)

[![asciicast](https://asciinema.org/a/5vNR7aTkpPyK4v4pPefRAYwec.svg)](https://asciinema.org/a/5vNR7aTkpPyK4v4pPefRAYwec)